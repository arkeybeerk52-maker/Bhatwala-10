package com.bhatwala.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
